package com.example.daftar_belanja_rifqi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
